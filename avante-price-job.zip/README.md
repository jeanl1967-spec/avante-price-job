# Avante weekly price check

Every Monday this reads the lowest nightly price for each property in the
Avante affiliate hub from StockNetwork's booking pages (a few upcoming
2-night stays per property) and saves the list to the Avante hooks site,
which fills "from R… per night" on the flyers.

* Runs by itself every Monday; to run it now: **Actions → Weekly price check → Run workflow**.
* Needs one secret: **RATES_TOKEN** (Settings → Secrets and variables → Actions).
* A property that can't be priced (fully booked on the sample dates) keeps last week's price.
